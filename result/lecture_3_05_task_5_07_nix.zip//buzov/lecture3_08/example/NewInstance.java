package buzov.lecture3_08.example;

import java.util.Scanner;

class One {

	void one() {
		System.out.println("one");
	}

}

public class NewInstance {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		try {
			String name = new Scanner(System.in).next();
			Object o = Class.forName(name).newInstance();
			if (o instanceof One)
				((One) o).one();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

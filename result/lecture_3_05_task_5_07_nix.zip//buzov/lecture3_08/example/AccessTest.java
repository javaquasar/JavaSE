package buzov.lecture3_08.example;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

class TestClass {
	private int k = 0;

	private void testPrivate() {
		System.out.println("Закрытый метод. k = " + k);
	}

}

public class AccessTest {

	public static void main(String[] args) throws Exception {
		// Получаем класс:
		Class<?> c = Class.forName("lesson308.TestClass");
		// Создаем объект:
		Object obj = c.newInstance();
		// Доступ к закрытому полю:
		Field f = c.getDeclaredField("k");
		f.setAccessible(true);
		f.set(obj, 1);
		// Доступ к закрытому методу:
		Method m = c.getDeclaredMethod("testPrivate");
		m.setAccessible(true);
		m.invoke(obj);
	}

}

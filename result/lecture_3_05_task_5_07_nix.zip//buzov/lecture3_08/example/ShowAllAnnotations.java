package buzov.lecture3_08.example;

import java.lang.annotation.Annotation;

import buzov.lecture3_08.example.annotation.NewAnnotation;

@Deprecated
@NewAnnotation(firstValue = 1)
class TestClass2 {

}

public class ShowAllAnnotations {

	public static void main(String[] args) {
		try {
			Class<?> cls = Class.forName("buzov.lecture3_08.example.TestClass2");
			for (Annotation ann : cls.getAnnotations())
				System.out.println(ann);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
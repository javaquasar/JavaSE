package buzov.lecture3_04;

import java.util.Formatter;

public class SimpleFormatString {

	public static void main(String[] args) {
		Formatter f = new Formatter();
		f.format("%s %c %nОсновы разработки приложений Java %S ", "Модуль", '2', "se");
		System.out.print(f);
	}

}

package buzov.lecture3_04.practice.task_8_08;

public class SortGroupOfStudents {

	public static void main(String[] args) {

	}

}

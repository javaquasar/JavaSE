package buzov.lecture3_04.practice.task_8_07;

import java.util.regex.Pattern;

/*Заменить в тексте все шаблоны типа %user%Nick%/user% 
 на <a href="http://www.my.by/search.htm?param=Nick">Nick</a>.*/

public class ReplacementTemplate {

	public static void main(String[] args) {
		String testString = new String("Hello %user%Nick%/user% !!! %user%Nick%/user%");
		Pattern p = Pattern.compile("%user%Nick%/user%"); // все пробелы в начале строки
		String s = p.matcher(testString).replaceAll("<a href=\"http://www.my.by/search.htm?param=Nick\">Nick</a>");
		System.out.println(s);
	}

}

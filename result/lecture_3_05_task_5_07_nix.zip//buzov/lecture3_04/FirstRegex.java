package buzov.lecture3_04;

import java.util.regex.*;

public class FirstRegex {

	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("text");
		Matcher matcher = pattern.matcher("text");
		System.out.println(matcher.matches());
	}

}
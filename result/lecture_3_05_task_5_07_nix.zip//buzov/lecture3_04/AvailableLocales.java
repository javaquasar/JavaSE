package buzov.lecture3_04;

import java.util.Locale;
import java.text.NumberFormat;

public class AvailableLocales {

	public static void main(String[] args) {
		Locale list[] = NumberFormat.getAvailableLocales();
		for (Locale locale : list) {
			System.out.printf("%-25s %s%n", locale.toString(), locale.getDisplayName());
		}
	}

}

package buzov.lecture3_04;

import java.util.Scanner;
import java.util.StringTokenizer;

public class UsingStringTokenizer {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String sentence = scanner.nextLine();
		StringTokenizer st = new StringTokenizer(sentence);
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
	}

}
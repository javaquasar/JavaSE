package buzov.lecture2_04;

import java.util.Arrays;

public class MathRandomTest {

	public static void main(String[] args) {
		double[] a = new double[5];
		for (int i = 0; i < a.length; i++) {
			a[i] = Math.random() * 10; // случайные значения от 0 до 10
		}
		System.out.println(Arrays.toString(a));
	}

}

package buzov.lecture2_04;

public class SumOfElements2 {
	public static void main(String[] args) {
		double a[] = { 1, 2, 1, 2.5, 1 };
		double sum = 0;
		for (double x : a) {
			sum += x;
		}
		System.out.println("Sum is " + sum);
	}
}

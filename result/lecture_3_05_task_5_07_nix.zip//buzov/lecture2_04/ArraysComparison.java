package buzov.lecture2_04;

import java.util.Arrays;

public class ArraysComparison {

	public static void main(String[] args) {
		double[] a = null, b = null;
		System.out.println(Arrays.equals(a, b)); // true
		a = new double[] { 1, 2, 3, 4 };
		b = new double[4];
		System.out.println(Arrays.equals(a, b)); // false
		System.arraycopy(a, 0, b, 0, a.length);
		System.out.println(Arrays.equals(a, b)); // true
		b[3] = 4.5;
		System.out.println(Arrays.equals(a, b)); // false
	}

}

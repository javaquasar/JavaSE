package buzov.lecture2_04;

import java.util.Arrays;

public class SortClassLibrary {
	public static void main(String[] args) {
		double[] a = { 11, 2.5, 4, 3, 5 };
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
	}
}

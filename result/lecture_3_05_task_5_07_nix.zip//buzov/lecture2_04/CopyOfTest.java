package buzov.lecture2_04;

import java.util.Arrays;

public class CopyOfTest {

	public static void main(String[] args) {
		int[] a = { 1, 2, 3, 4 };
		int[] b = Arrays.copyOf(a, 3);
		System.out.println(Arrays.toString(b));// [1, 2, 3]
		int[] c = Arrays.copyOf(a, 6);
		System.out.println(Arrays.toString(c));// [1, 2, 3, 4, 0, 0]
		int[] d = Arrays.copyOfRange(a, 1, 3);
		System.out.println(Arrays.toString(d));// [2, 3]
	}

}
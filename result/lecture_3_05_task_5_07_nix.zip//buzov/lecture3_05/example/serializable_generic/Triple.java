package buzov.lecture3_05.example.serializable_generic;

import java.io.*;

class Triple<T> implements Serializable {
	private static final long serialVersionUID = 7512336951571111736L;
	T x, y, z;

	Triple(T x, T y, T z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
}

package buzov.lecture3_05.example.serializable_object_with_array;

import java.io.Serializable;

public class ArrayOfPairs implements Serializable {
	private static final long serialVersionUID = 5308689750632711432L;
	Pair[] pairs;

	public ArrayOfPairs(Pair[] pairs) {
		this.pairs = pairs;
	}

}

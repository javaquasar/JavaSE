package buzov.lecture3_05.example.serializable_object_with_array;

import java.io.*;

public class ArrayDeserialization {

	public static void main(String[] args) throws ClassNotFoundException {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("./file/lecture_3_05_example_array_serialization.dat"))) {
			ArrayOfPairs arrayOfPairs = (ArrayOfPairs) in.readObject();
			for (Pair p : arrayOfPairs.pairs)
				System.out.println(p.x + " " + p.y);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
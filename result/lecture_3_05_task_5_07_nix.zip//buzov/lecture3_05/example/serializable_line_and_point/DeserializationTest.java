package buzov.lecture3_05.example.serializable_line_and_point;

import java.io.*;

public class DeserializationTest {

	public static void main(String[] args) throws ClassNotFoundException {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("./file/lecture_3_05_example_line_and_point_serialization.dat"))) {
			Line line = (Line) in.readObject();
			System.out.println(line.getFirst().getX() + " " + line.getFirst().getY() + " " + line.getSecond().getX() + " " + line.getSecond().getY());
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
	}

}

package buzov.lecture2_07.practice.interface_minfunction;

public class InterfaceTest {
	public static void main(String[] args) {
		System.out.println(Solver.solve(3, 2, 0.000001, new MyFunction()));
	}
}

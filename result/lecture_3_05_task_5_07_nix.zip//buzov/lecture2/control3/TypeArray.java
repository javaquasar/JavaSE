package buzov.lecture2.control3;

public enum TypeArray {
	OBJECT,
	DOUBLE_ARRAY,
	ARRAY;
}

package buzov.lecture2_03;

import java.util.Scanner;

public class ExpressionTest {

  static double f(double x) {
    return x < -8 ? 100 : (x <= 1 ? 200 : 300);
  }

  @SuppressWarnings("resource")
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double x = scanner.nextDouble();
    double y = f(x);
    System.out.println(y);
  }

}

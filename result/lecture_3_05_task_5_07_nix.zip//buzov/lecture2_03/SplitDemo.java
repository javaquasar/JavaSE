package buzov.lecture2_03;

import java.util.Scanner;

public class SplitDemo {

  @SuppressWarnings("resource")
  public static void main(String[] args) {
    int n;
    System.out.println("Input n:");
    n = new Scanner(System.in).nextInt();
    int y = 0;
    for (int i = 1; i <= n; i++)
      y += i * i;
    System.out.println("y = " + y);
  }

}

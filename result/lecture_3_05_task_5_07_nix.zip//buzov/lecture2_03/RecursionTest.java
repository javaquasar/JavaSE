package buzov.lecture2_03;

import java.util.Scanner;

public class RecursionTest {

  static double power(double x, int n) {
    if (n < 0)
      return 1 / power(x, -n);
    if (n == 0)
      return 1;
    return x * power(x, n - 1);
  }

  @SuppressWarnings("resource")
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double x = scanner.nextDouble();
    int n = scanner.nextInt();
    double y = power(x, n);
    System.out.println(y);
  }

}

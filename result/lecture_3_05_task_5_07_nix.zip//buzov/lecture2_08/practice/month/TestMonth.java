package buzov.lecture2_08.practice.month;

public class TestMonth {

	public static void main(String[] args) {
		Month month = Month.APRIL;
		Month.printAll();
		System.out.println(month);
		System.out.println(month.getSeason());
		System.out.println(month.getNextMonth());
		System.out.println(month.getLastMonth());
	}
}

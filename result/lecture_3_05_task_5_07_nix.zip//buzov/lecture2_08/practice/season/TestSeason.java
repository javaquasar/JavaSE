package buzov.lecture2_08.practice.season;

public class TestSeason {

	public static void main(String[] args) {
		Season season = Season.SPRING;
		System.out.println(season);
		System.out.println(season.getNextSeason());
		System.out.println(season.getLastSeason());
		System.out.println(Season.valueOf("SPRING").ordinal());
	}

}

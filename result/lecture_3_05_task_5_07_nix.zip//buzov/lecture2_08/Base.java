package buzov.lecture2_08;

abstract class Base {
	int k;

	Base(int k) {
		this.k = k;
	}

	abstract void show();
}

package buzov.lecture2_08;

public class BaseTest {
	static void showBase(Base b) {
		b.show();
	}

	public static void main(String[] args) {
		showBase(new Base(10) {
			void show() {
				System.out.println(k);
			}
		});
	}

}
package buzov.lecture2_08;

public class GenderTest {

	public static void main(String[] args) {
		Gender g = Gender.FEMALE;
		System.out.println(g);
	}

}

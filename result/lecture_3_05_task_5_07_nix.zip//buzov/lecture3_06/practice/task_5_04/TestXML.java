package buzov.lecture3_06.practice.task_5_04;

public class TestXML {

	public static void main(String[] args) {
		XMLSerialization serialization = new XMLSerialization();
		XMLDeserialization deserialization = new XMLDeserialization();
		
		serialization.main(args);
		deserialization.main(args);
	}

}

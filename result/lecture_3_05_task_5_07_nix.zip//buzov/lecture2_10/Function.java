package buzov.lecture2_10;

public interface Function {
default double f(double x) {
  return x * x;
}
}

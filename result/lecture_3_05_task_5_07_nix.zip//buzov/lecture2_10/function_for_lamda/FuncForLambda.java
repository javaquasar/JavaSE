package buzov.lecture2_10.function_for_lamda;

public interface FuncForLambda {
	double f(double x);
}

package buzov.lecture3_09.example;

import javax.swing.table.AbstractTableModel;

public class NewTableModel extends AbstractTableModel {

	public int getRowCount() {
		return 2;
	}

	public int getColumnCount() {
		return 2;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return rowIndex + " " + columnIndex;
	}

}

package buzov.lecture3_09.example;

import javax.swing.*;

public class HelloWorld {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Привет");
		frame.getContentPane().add(new JLabel("Привет, мир!"));
		frame.pack();
		frame.setVisible(true);
	}

}

package buzov.lecture2_05;

import java.util.*;

public class AllWords {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		String s = new Scanner(System.in).nextLine();
		StringTokenizer st = new StringTokenizer(s);
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
	}

}
package buzov.lecture2_05;

public class SpaceRemover {
	public static void main(String[] args) {
		System.out.println(args[0]);
		String s = args[0];
		while (s.indexOf("  ") >= 0)
			s = s.replaceAll("  ", " ");
		System.out.println(s);
	}
}

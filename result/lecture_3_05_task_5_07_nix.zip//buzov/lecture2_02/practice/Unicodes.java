package buzov.lecture2_02.practice;

public class Unicodes {

	public static void main(String[] args) {
		for (char c = 1072; c <= 1120; c++) {
			System.out.println(c + " " + (int) c);
		}
	}

}

package buzov.lecture2_01.exemple;

import java.util.Scanner;

public class Average {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Введите a и b: ");
		double a = scanner.nextDouble();
		double b = scanner.nextDouble();
		double c = (a + b) / 2;
		System.out.println("Среднее арифметическое: " + c);
	}

}

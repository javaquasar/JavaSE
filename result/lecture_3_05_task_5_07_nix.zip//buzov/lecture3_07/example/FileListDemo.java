package buzov.lecture3_07.example;

import java.io.IOException;
import java.nio.file.*;

public class FileListDemo {

	public static void main(String[] args) {
		Path dir = Paths.get("c:/Windows");
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
			for (Path p : ds) {
				System.out.println(p.getFileName());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
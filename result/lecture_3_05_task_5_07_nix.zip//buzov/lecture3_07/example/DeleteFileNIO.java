package buzov.lecture3_07.example;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DeleteFileNIO {
	  public static void main(String[] args) { 
	        Path pathSource = Paths.get("Вставьте сюда путь к файлу/директории для удаления"); 
	        try { 
	            Files.delete(pathSource); 
	            System.out.println("File deleted successfully"); 
		} catch (IOException e) { 
	            e.printStackTrace(); 
	        } 
	    } 
}

package buzov.lecture3_07.practice.task_5_01;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class FileManagement {

	public static void main(String[] args) throws IOException {
		File dir = new File(".");
		File file = new File(dir+"\\test.txt");
		file.createNewFile();
		System.out.println(Arrays.asList(dir.list()));
		file.delete();
		
	}
}

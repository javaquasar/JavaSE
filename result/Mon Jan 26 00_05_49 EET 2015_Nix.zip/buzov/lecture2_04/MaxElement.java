package buzov.lecture2_04;

public class MaxElement {

	public static void main(String[] args) {
		int[] a = { 1, 2, 14, 8 };
		int indexOfMax = 0;
		for (int i = 1; i < a.length; i++) {
			if (a[i] > a[indexOfMax]) {
				indexOfMax = i;
			}
		}
		System.out.println(indexOfMax + " " + a[indexOfMax]);
	}

}

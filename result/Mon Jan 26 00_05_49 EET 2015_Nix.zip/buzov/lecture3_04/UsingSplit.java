package buzov.lecture3_04;

import java.util.Scanner;

public class UsingSplit {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String sentence = scanner.nextLine();
		String[] words = sentence.split("\\s");
		for (String word : words)
			System.out.println(word);
	}

}

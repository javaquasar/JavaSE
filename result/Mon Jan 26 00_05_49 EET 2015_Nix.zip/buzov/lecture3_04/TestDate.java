package buzov.lecture3_04;

import java.text.DateFormat;
import java.time.DateTimeException;
import java.util.Date;

public class TestDate {
    public static void main(String[] args) {
        DateFormat dateFormat = DateFormat.getDateInstance();
        Date date = new Date();
        String form = dateFormat.format(date);
        System.out.println(form);
    }
}

package buzov.lecture3_04;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

public class NumberPrinter {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		NumberFormat form = NumberFormat.getInstance(new Locale("uk"));
		Scanner scan = new Scanner(System.in);
		double x = scan.nextDouble();
		System.out.println(form.format(x));
	}

}

package buzov.lecture3_08.example;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class EvalScript {

	public static void main(String[] args) throws Exception {
		ScriptEngineManager factory = new ScriptEngineManager();
		ScriptEngine engine = factory.getEngineByName("JavaScript");
		engine.eval("print('Hello, World')");
	}

}

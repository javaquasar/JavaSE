package buzov.lecture3_08.example.annotation;

@NewAnnotation(firstValue = 10, secondValue = "A")
public class SomeAnnotatedClass {

}
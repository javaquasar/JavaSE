package buzov.lecture3_08.example.annotation;

public class NewAnnotationProcessor {

	public static void main(String[] args) {
		try {
			Class<?> cls = Class.forName("lesson308.SomeAnnotatedClass");
			if (cls.isAnnotationPresent(NewAnnotation.class)) {
				NewAnnotation ann = cls.getAnnotation(NewAnnotation.class);
				System.out.println(ann.firstValue());
				System.out.println(ann.secondValue());
			} else
				System.out.println("No such annotation!");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}

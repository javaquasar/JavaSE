package buzov.lecture3_08.example.annotation;

import java.lang.annotation.*;

@Target(value = ElementType.TYPE)
@Retention(value = RetentionPolicy.RUNTIME)
public @interface NewAnnotation {
	int firstValue();

	String secondValue() default "second";
}

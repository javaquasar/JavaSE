package buzov.lecture3_06.example.serialization;

public class Point implements java.io.Serializable {
	private static final long serialVersionUID = -3566722853756147165L;
	private double x, y;

	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

}

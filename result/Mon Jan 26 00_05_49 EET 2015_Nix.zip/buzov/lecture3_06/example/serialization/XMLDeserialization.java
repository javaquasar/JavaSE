package buzov.lecture3_06.example.serialization;

import java.beans.XMLDecoder;
import java.io.*;

public class XMLDeserialization {

	public static void main(String[] args) {
		try (XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream(
				"Line.xml"))) {
			Line line = (Line) xmlDecoder.readObject();
			System.out.println(line.getFirst().getX() + " "
					+ line.getFirst().getY() + " " + line.getSecond().getX()
					+ " " + line.getSecond().getY());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
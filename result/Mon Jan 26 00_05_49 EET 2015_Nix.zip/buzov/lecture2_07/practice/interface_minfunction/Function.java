package buzov.lecture2_07.practice.interface_minfunction;

public interface Function {
	double f(double x);
}


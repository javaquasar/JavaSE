package buzov.lecture2_07.practice.interface_minfunction;

public class MyFunction implements Function{
	
	public double f(double x){
		return x*x+2*x;
	}
}


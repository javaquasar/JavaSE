package buzov.lecture2_07.practice.matrix_copy;

public interface MyIInterface {

}

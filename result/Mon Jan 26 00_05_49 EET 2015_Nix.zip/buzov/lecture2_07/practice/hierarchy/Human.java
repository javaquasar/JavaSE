package buzov.lecture2_07.practice.hierarchy;

public class Human {
	String name = "";
	String surName = "";
	int age = 0;

	public Human(String name, String surName, int age) {
		super();
		this.name = name;
		this.surName = surName;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public String getSurName() {
		return surName;
	}

	@Override
	public String toString() {
		return "Человек, имя: " + name + ", фамилия: " + surName
				+ ", возраст: " + age;
	}
}

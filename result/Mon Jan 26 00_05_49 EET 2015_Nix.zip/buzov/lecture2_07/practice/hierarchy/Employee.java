package buzov.lecture2_07.practice.hierarchy;

public abstract class Employee extends Citizen {

	public Employee(String name, String surName, int age, String registration) {
		super(name, surName, age, registration);
	}

	abstract double getSallary();

	abstract void payroll();

}

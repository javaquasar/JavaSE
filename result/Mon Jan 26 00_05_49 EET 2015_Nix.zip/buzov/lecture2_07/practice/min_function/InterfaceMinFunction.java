package buzov.lecture2_07.practice.min_function;

public interface InterfaceMinFunction {

	double findMin(double x);

	double solve(double a, double b, double eps);
}

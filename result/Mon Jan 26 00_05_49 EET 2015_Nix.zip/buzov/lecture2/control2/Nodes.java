package buzov.lecture2.control2;

public enum Nodes {
	Kharkiv,
	Novoselovka,
	Merefa,
	Lozovaja,
	Lyubotin,
	Krasnohrad;
	
	@Override
	public String toString() {
		return this.name();
	}
}

package buzov.lecture2_09.practice.group_2;

import java.util.Comparator;

public class StudentComparator implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		return -Integer.compare(o1.getAge(), o2.getAge());
	}
}

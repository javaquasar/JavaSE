package buzov.lecture2_08;

public class MoonsOfMarsTest {

	public static void main(String[] args) {
		MoonOfMars m = MoonOfMars.PHOBOS;
		System.out.println(m); // PHOBOS. 9377.0 km from Mars
	}

}

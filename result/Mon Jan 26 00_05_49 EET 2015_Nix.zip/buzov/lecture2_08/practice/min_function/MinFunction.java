package buzov.lecture2_08.practice.min_function;

public abstract class MinFunction {
	
	double a;
	double b;
	double eps;
	
	
	public MinFunction(double a, double b, double eps) {
		this.a = a;
		this.b = b;
		this.eps = eps;
	}

	abstract double findMin(double x);

	abstract double solve();
}

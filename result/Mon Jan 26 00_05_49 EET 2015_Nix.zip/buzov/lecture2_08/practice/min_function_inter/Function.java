package buzov.lecture2_08.practice.min_function_inter;

public interface Function {
	
	double findMin(double x);
	
}

package buzov.lecture2_08;

public class EnumTest {

	public static void main(String[] args) {
		DayOfWeek d = DayOfWeek.MONDAY;
		for (int i = 0; i < 7; i++) {
			d = d.next();
			System.out.println(d + " " + d.isWeekend());
		}
	}

}

package buzov.lecture2_08;

enum Gender {
	MALE, FEMALE;

	@Override
	public String toString() {
		switch (this) {
		case MALE:
			return "мужской пол";
		case FEMALE:
			return "женский пол";
		}
		return "что-то невозможное!";
	}

}



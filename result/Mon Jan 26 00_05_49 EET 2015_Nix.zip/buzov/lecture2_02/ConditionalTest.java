package buzov.lecture2_02;

import java.util.Scanner;

public class ConditionalTest {

  @SuppressWarnings("resource")
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double x = scanner.nextDouble();
    double y = x < -8 ? 100 : (x <= 1 ? 200 : 300);
    System.out.println(y);
  }

}

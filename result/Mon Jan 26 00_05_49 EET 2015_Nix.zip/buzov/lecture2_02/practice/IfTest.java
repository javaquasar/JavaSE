package buzov.lecture2_02.practice;

import java.util.Scanner;

public class IfTest {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Введите число x.");
		double x = scanner.nextDouble();
		byte y = 0;

		if (x < 0) {
			y = -1;
		} else if (x == 0) {
			y = 0;
		} else if (x > 0) {
			y = 1;
		}

		System.out.println(y);

	}
}

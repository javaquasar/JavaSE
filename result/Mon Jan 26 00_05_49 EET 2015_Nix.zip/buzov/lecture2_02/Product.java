package buzov.lecture2_02;

import java.util.Scanner;

public class Product {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Введите x, k и n:");
		double x = scanner.nextDouble();
		int k = scanner.nextInt();
		int n = scanner.nextInt();
		double y = 1;
		for (int i = 0; i <= n; i++) {
			if (i == k)
				continue;
			y *= (x + i);
		}
		System.out.println("y = " + y);
	}

}

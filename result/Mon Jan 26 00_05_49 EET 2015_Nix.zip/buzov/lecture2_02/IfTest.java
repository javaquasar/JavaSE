package buzov.lecture2_02;

import java.util.Scanner;

public class IfTest {

  @SuppressWarnings("resource")
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double x = scanner.nextDouble();
    double y;
    if (x < -8)
        y = 100;
    else
      if (x <= 1)
        y = 200;
      else
        y = 300;
    System.out.println(y);
  }

}

package buzov.lecture2_02;

import java.util.Scanner;

@SuppressWarnings("resource")
public class ToBinary {

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    byte b = scanner.nextByte();
    for (int i = 7; i >= 0; i--) {
      System.out.print((byte)(1 & (b >> i)));
    }
  }

}

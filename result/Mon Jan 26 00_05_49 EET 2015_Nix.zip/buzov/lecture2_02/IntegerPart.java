package buzov.lecture2_02;

import java.util.Scanner;

public class IntegerPart {

  @SuppressWarnings("resource")
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double x = scanner.nextDouble();
    int n = (int) x;
    System.out.println(n);
  }

}

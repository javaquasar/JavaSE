package buzov.lecture2_02;

public class Unicodes {

	public static void main(String[] args) {
		for (char c = 'А'; c <= 'Я'; c++) {
			System.out.println(c + " " + (int) c);
		}
	}

}

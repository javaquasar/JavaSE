package buzov.lecture2_06;

public class SomeClass {
	private int i;
	private double x;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}
}

package buzov.lecture3_05.example.serializable;

import java.io.*;

public class DataDeserialization {

	public static void main(String[] args) throws ClassNotFoundException {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("./file/lecture_3_05_example_countries.dat"))) {
			Continent continent = (Continent) in.readObject();
			for (Country c : continent.getCountries())
				System.out.println(c.getName() + " " + c.getArea() + " " + c.getPopulation());
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
	}

}

package buzov.lecture3_05.example.serializable;

import java.io.Serializable;

public class Continent implements Serializable {
	private static final long serialVersionUID = 8433147861334322335L;
	private String name;
	private Country[] countries;

	public Continent(String name, Country... countries) {
		this.name = name;
		this.countries = countries;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Country[] getCountries() {
		return countries;
	}

	public void setCountries(Country[] countries) {
		this.countries = countries;
	}

}

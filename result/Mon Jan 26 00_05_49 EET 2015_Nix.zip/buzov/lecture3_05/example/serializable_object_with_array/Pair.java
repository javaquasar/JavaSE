package buzov.lecture3_05.example.serializable_object_with_array;

import java.io.*;

public class Pair implements Serializable {
	private static final long serialVersionUID = 6802552080830378203L;
	double x, y;

	public Pair(double x, double y) {
		this.x = x;
		this.y = y;
	}

}

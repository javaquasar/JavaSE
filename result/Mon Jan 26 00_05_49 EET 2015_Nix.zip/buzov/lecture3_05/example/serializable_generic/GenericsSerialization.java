package buzov.lecture3_05.example.serializable_generic;

import java.io.*;

public class GenericsSerialization {

	public static void main(String[] args) {
		Triple<Integer> t1 = new Triple<>(1, 2, 3);
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("./file/lecture_3_05_example_integers.dat"))) {
			out.writeObject(t1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
		Triple<String> t2 = new Triple<>("A", "B", "C");
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("./file/lecture_3_05_example_strings.dat"))) {
			out.writeObject(t2);
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
	}

}

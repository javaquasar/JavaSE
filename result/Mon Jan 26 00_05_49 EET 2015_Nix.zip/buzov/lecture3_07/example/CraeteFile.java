package buzov.lecture3_07.example;

import java.io.File;
import java.io.IOException;

public class CraeteFile {
	public static void main(String[] args) throws IOException {
		File file = new File("C:\\test1\\test.xml");
		File dir = file.getParentFile();
		if (false == file.exists()) {
			dir.mkdir();
		}
		file.createNewFile();
	}
}

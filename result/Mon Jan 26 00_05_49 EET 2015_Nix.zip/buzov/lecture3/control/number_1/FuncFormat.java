package buzov.lecture3.control.number_1;

import java.text.Collator;

public interface FuncFormat<E> {
	public int sort(Object s1, Object s2, Collator collator);
}

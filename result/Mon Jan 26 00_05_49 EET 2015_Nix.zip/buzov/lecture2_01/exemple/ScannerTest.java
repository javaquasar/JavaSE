package buzov.lecture2_01.exemple;

import java.util.Scanner;

public class ScannerTest {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String s = scanner.next(); // чтение строки
		double d = scanner.nextDouble(); // чтение вещественного числа
		int i = scanner.nextInt(); // чтение целого числа
		System.out.printf("%f %d%n", d, i);
	}

}

package buzov.lecture2_01.exemple;

public class HelloWorld {
	  public static void main(String[] args) {
	    System.out.println("Привет, Мир!");
	  }
	}

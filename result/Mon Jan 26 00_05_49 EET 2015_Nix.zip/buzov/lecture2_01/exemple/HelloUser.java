package buzov.lecture2_01.exemple;

public class HelloUser {

	public static void main(String[] args) {
		if (args.length > 0)
			System.out.println("Привет, " + args[0] + "!");
		else
			System.out.println("Привет, незнакомец!");
	}

}

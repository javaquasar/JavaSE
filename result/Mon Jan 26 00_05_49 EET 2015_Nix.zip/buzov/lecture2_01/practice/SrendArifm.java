package buzov.lecture2_01.practice;

import java.util.Scanner;

/*8.1 Реализация тестовых примеров

Осуществить создание приведенных выше проектов в среде Eclipse. 
Использовать отладчик. Запустить созданные программы из командной строки.*/

public class SrendArifm {
@SuppressWarnings("resource")
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите a и b: ");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double y = Math.sqrt(a * b);

        System.out.println("Среднее геометрическое a и b= " + y);

    }
}

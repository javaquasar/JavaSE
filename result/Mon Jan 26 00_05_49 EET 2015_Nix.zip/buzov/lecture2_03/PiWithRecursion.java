package buzov.lecture2_03;

import java.util.Scanner;

public class PiWithRecursion {

  static double pi(double eps, int n) {
    double z = 4.0 / n;
    if (z < eps)
      return z;
    return z - pi(eps, n + 2);
  }

  static double pi(double eps) {
    return pi(eps, 1);
  }

  @SuppressWarnings("resource")
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    double eps = scanner.nextDouble();
    double y = pi(eps);
    System.out.println(y);
  }

}

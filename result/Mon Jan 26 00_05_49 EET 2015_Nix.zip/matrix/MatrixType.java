package matrix;

public enum MatrixType {
	
	DOUBLE,
	DOUBLE_ARRAY,
        DOUBLE_ONE;

}

package matrix;

public class MatrixDouble2 extends MatrixDouble{
	
	public MatrixDouble2(int i, int j) {
		super(i, j);
	}

}
